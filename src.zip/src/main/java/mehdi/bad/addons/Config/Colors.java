package mehdi.bad.addons.Config;

import java.awt.*;

public class Colors {

    public static Color RED = new Color(255, 85, 85);

    public static Color WHITE = new Color(255, 255, 255);

    public static Color GREEN = new Color(85, 255, 85);

    public static Color TRANSPARENT = new Color(255, 255, 255, 65);
}
