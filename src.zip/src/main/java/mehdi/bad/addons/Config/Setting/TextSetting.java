package mehdi.bad.addons.Config.Setting;

import java.lang.reflect.Field;

import mehdi.bad.addons.Config.Property;

public class TextSetting extends Setting {
    public TextSetting(Property var1, Field var2) {
        super(var1, var2);
    }

    public boolean set(Object var1) {
        return super.set(var1);
    }
}
