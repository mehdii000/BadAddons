package mehdi.bad.addons.Features.Kuudra;

public class SupplyTimer {

    private final String pickup_regex = "\\[\\|+\\]\\s*(\\d+)%";

}
