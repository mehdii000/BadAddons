package mehdi.bad.addons.Objects;

import java.util.ArrayList;

public class KeyBindUtils {

    public static final ArrayList keyBinds = new ArrayList();

    public static void addKeyBind(KeyBind var0) {
        keyBinds.add(var0);
    }
}
